fx_version 'cerulean'
game 'gta5'

author 'xd.xd'
description 'Gugolás System'
version '1.0.0'

client_script 'client.lua'
server_script 'server.lua'
